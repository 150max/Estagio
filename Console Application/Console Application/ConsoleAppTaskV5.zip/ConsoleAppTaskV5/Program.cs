﻿using System;
using System.IO;
using System.Data.SqlClient;
using System.Text;
using System.Threading.Tasks;
using FluentEmail.Smtp;
using FluentEmail.Core;
using System.Net;
using System.Net.Mail;
using System.Net.Mime;
using System.Net.Http;
using System.Web;
using Twilio;
using Twilio.Rest.Api.V2010.Account;

namespace ConsoleAppTaskV5
{
    class Program
    {
        private static string abc;

        static void Main(string[] args)
        {
            RunSchedule();
            Mail();
            SMS();
        }


        public static void RunSchedule()
        {
            //String Conexao
            Console.WriteLine("Getting Connection...");
            SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder();
            builder.DataSource = "DESKTOP-R7QRMCV";
            builder.UserID = "Marcelo";
            builder.Password = "marcelo1";
            builder.InitialCatalog = "DW_NSA";

            // Conexao
            SqlConnection connection = new SqlConnection(builder.ConnectionString);
            connection.Open();

            // Query
            StringBuilder sb = new StringBuilder();
            sb.Append("exec Procedimento3");

            String sql = sb.ToString();


            //Comando para executar a Query
            SqlCommand command = new SqlCommand(sql, connection);
            SqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                StringBuilder result = new StringBuilder();
                result.Append($"Foi transcendido o limite de {reader.GetSqlString(0)}");

                Console.WriteLine(result.ToString());
                abc = result.ToString();
            }
        }

        public static void Mail()
        {
            if (string.IsNullOrEmpty(abc))
            {
                Console.WriteLine("email não enviado");
            }
            else
            {
                try
                {

                    MailMessage mail = new MailMessage();
                    SmtpClient SmtpServer = new SmtpClient("smtp.office365.com");


                    mail.From = new MailAddress("marcelo2007@outlook.pt");
                    mail.To.Add("marcelo2007@outlook.pt");
                    mail.Body = abc;
                    mail.Subject = "Alerta ";



                    SmtpServer.Port = 587;
                    SmtpServer.Credentials = new System.Net.NetworkCredential("marcelo2007@outlook.pt", "Qwerty12345");
                    SmtpServer.EnableSsl = true;



                    SmtpServer.Send(mail);
                    Console.WriteLine("email enviado");
                    SmtpServer.Dispose();

                }

                catch (Exception ex)

                {
                    Console.WriteLine("email não enviado");
                    Console.WriteLine(ex.Message);
                }
            }







        }

        public static void SMS()
        {
            try
            {
                string accountSid = Environment.GetEnvironmentVariable("twiliosid");
                string authToken = Environment.GetEnvironmentVariable("twilioauth");

                TwilioClient.Init(accountSid, authToken);

                var message = MessageResource.Create(
                    body: abc,
                    from: new Twilio.Types.PhoneNumber("+19853154495"),
                    to: new Twilio.Types.PhoneNumber("+351910077556")
                );
                Console.WriteLine("sms  enviado");
                Console.WriteLine(message.Sid);
            }
            catch (Exception ex)
            {
                Console.WriteLine("sms não enviado");
                Console.WriteLine(ex.Message);
            }

        }



    }
}