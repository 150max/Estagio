﻿/*using ProjetoEstagioV5.Dao;
using ProjetoEstagioV5.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ProjetoEstagioV5.Repositorio
{
    public class ProductRepositorio
    {
        private readonly DaoProduct _daoProduct;

        public  ProductRepositorio()
        {
            _daoProduct = new DaoProduct();
        }

        public List<Product> GetProducts
        {
            get
            {
                return _daoProduct.GetProducts();
            }
        }
    }
}
*/